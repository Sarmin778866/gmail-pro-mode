
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate, Link, useNavigate } from 'react-router-dom';
import { 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  query, 
  orderBy, 
  where,
  runTransaction
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";
import { auth, db } from './firebase';
import { User, Transaction, AppState, TransactionStatus } from './types';
import { PLANS, PAYMENT_METHODS, ADMIN_EMAIL } from './constants';
import GmailSim from './components/GmailSim';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [isConfigMissing, setIsConfigMissing] = useState(false);

  useEffect(() => {
    const config = auth.app.options;
    if (!config.apiKey || config.apiKey === "YOUR_ACTUAL_API_KEY" || config.apiKey.includes("PLACEHOLDER") || config.apiKey === "") {
      setIsConfigMissing(true);
      setLoading(false);
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      try {
        if (fbUser) {
          console.log("System Check: Auth User Found ->", fbUser.email);
          const userRef = doc(db, "users", fbUser.uid);
          const userDoc = await getDoc(userRef);
          
          const isAdmin = fbUser.email?.toLowerCase() === ADMIN_EMAIL.toLowerCase();

          if (userDoc.exists()) {
            let userData = userDoc.data() as User;
            
            // Force Admin role if email matches but role is wrong
            if (isAdmin && userData.role !== 'ADMIN') {
              console.log("Upgrading existing user to ADMIN...");
              await updateDoc(userRef, { 
                role: 'ADMIN',
                activePlan: 'Infinite',
                remainingLimit: 999999 
              });
              userData.role = 'ADMIN';
            }
            setCurrentUser({ id: fbUser.uid, ...userData });
          } else {
            // Profile missing - Create it now
            console.log("Creating Firestore profile for:", fbUser.email);
            const newProfile = {
              fullName: isAdmin ? "System Admin" : (fbUser.displayName || "User"),
              email: fbUser.email || "",
              role: isAdmin ? 'ADMIN' : 'USER',
              activePlan: isAdmin ? 'Infinite' : 'None',
              gmailLimit: isAdmin ? 999999 : 0,
              remainingLimit: isAdmin ? 999999 : 0
            };
            
            try {
              await setDoc(userRef, newProfile);
              console.log("Firestore profile created successfully in 'users' collection.");
              setCurrentUser({ id: fbUser.uid, ...newProfile } as User);
            } catch (fsError: any) {
              console.error("Firestore Write Error:", fsError);
              alert("Firestore Error: আপনার ডাটাবেস রুলস চেক করুন। ডাটা সেভ করা যাচ্ছে না।");
            }
          }
        } else {
          setCurrentUser(null);
        }
      } catch (err) {
        console.error("Auth process error:", err);
      } finally {
        setLoading(false);
      }
    });
    return () => unsubscribe();
  }, []);

  // Listeners for Realtime Data
  useEffect(() => {
    if (!currentUser || isConfigMissing) return;

    const userRef = doc(db, "users", currentUser.id);
    const unsubProfile = onSnapshot(userRef, (doc) => {
      if (doc.exists()) {
        setCurrentUser(prev => prev ? { ...prev, ...doc.data() } : null);
      }
    });

    let unsubUsers = () => {};
    if (currentUser.role === 'ADMIN') {
      unsubUsers = onSnapshot(collection(db, "users"), (snapshot) => {
        const userList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as User));
        setUsers(userList);
      });
    }

    return () => {
      unsubProfile();
      unsubUsers();
    };
  }, [currentUser?.id, currentUser?.role, isConfigMissing]);

  useEffect(() => {
    if (!currentUser || isConfigMissing) return;

    let q = query(collection(db, "transactions"), orderBy("createdAt", "desc"));
    if (currentUser.role !== 'ADMIN') {
      q = query(collection(db, "transactions"), where("userId", "==", currentUser.id), orderBy("createdAt", "desc"));
    }

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const txList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction));
      setTransactions(txList);
    });

    return () => unsubscribe();
  }, [currentUser?.id, currentUser?.role, isConfigMissing]);

  const login = async (email: string, pass: string) => {
    try {
      await signInWithEmailAndPassword(auth, email, pass);
      return true;
    } catch (e: any) {
      console.error("Login Error:", e);
      alert("লগইন ব্যর্থ: ইমেইল বা পাসওয়ার্ড ভুল হতে পারে। " + e.message);
      return false;
    }
  };

  const signup = async (name: string, email: string, pass: string) => {
    try {
      const res = await createUserWithEmailAndPassword(auth, email, pass);
      const isAdmin = email.toLowerCase() === ADMIN_EMAIL.toLowerCase();
      const newUser = {
        fullName: name,
        email: email,
        role: isAdmin ? 'ADMIN' : 'USER',
        activePlan: isAdmin ? 'Infinite' : 'None',
        gmailLimit: isAdmin ? 999999 : 0,
        remainingLimit: isAdmin ? 999999 : 0
      };
      await setDoc(doc(db, "users", res.user.uid), newUser);
      setCurrentUser({ id: res.user.uid, ...newUser } as User);
      return true;
    } catch (e: any) {
      alert("Signup Error: " + e.message);
      return false;
    }
  };

  const logout = () => signOut(auth);

  const addTransaction = async (t: any) => {
    if (!currentUser) return;
    try {
      await addDoc(collection(db, "transactions"), {
        ...t,
        userId: currentUser.id,
        userEmail: currentUser.email,
        status: 'PENDING',
        createdAt: new Date().toISOString()
      });
      alert('পেমেন্ট রিকোয়েস্ট পাঠানো হয়েছে!');
    } catch (e: any) {
      alert("Transaction Error: " + e.message);
    }
  };

  const updateTransactionStatus = async (txId: string, status: TransactionStatus) => {
    const tx = transactions.find(t => t.id === txId);
    if (!tx) return;

    try {
      await runTransaction(db, async (transaction) => {
        const txRef = doc(db, "transactions", txId);
        const userRef = doc(db, "users", tx.userId);
        
        transaction.update(txRef, { status });

        if (status === 'APPROVED') {
          const userSnap = await transaction.get(userRef);
          if (userSnap.exists()) {
            const plan = PLANS.find(p => p.id === tx.planId);
            const userData = userSnap.data();
            transaction.update(userRef, {
              activePlan: tx.planName,
              gmailLimit: (userData.gmailLimit || 0) + (plan?.limit || 0),
              remainingLimit: (userData.remainingLimit || 0) + (plan?.limit || 0)
            });
          }
        }
      });
    } catch (e: any) {
      alert("Error: " + e.message);
    }
  };

  const useGmailSlot = async () => {
    if (!currentUser || currentUser.remainingLimit <= 0) return false;
    try {
      const userRef = doc(db, "users", currentUser.id);
      await updateDoc(userRef, {
        remainingLimit: currentUser.remainingLimit - 1
      });
      return true;
    } catch (e: any) {
      console.error("Limit update error:", e);
      return false;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 font-sans">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-600 mx-auto"></div>
          <p className="mt-4 text-gray-600 font-medium">অ্যাকাউন্ট চেক করা হচ্ছে...</p>
        </div>
      </div>
    );
  }

  return (
    <HashRouter>
      <Routes>
        <Route path="/login" element={<LoginPage onLogin={login} currentUser={currentUser} />} />
        <Route path="/signup" element={<SignupPage onSignup={signup} currentUser={currentUser} />} />
        <Route 
          path="/dashboard" 
          element={
            currentUser ? (
              currentUser.role === 'ADMIN' ? 
              <AdminDashboard 
                state={{ users, transactions, currentUser }} 
                onLogout={logout} 
                onUpdateTx={updateTransactionStatus} 
              /> : 
              <UserDashboard 
                state={{ users, transactions, currentUser }} 
                onLogout={logout} 
                onAddTx={addTransaction}
                onUseGmail={useGmailSlot}
              />
            ) : <Navigate to="/login" />
          } 
        />
        <Route path="/" element={<Navigate to="/dashboard" />} />
      </Routes>
    </HashRouter>
  );
};

// --- Dashboard & Auth Components (Minimal UI) ---

const LoginPage = ({ onLogin, currentUser }: any) => {
  const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const navigate = useNavigate();

  if (currentUser) return <Navigate to="/dashboard" />;

  const handleLogin = async (e: any) => {
    e.preventDefault();
    setSubmitting(true);
    const ok = await onLogin(email, pass);
    if (ok) navigate('/dashboard');
    setSubmitting(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-indigo-700 p-4">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl p-8">
        <h2 className="text-3xl font-black text-gray-800 mb-8 text-center tracking-tight">Login</h2>
        <form onSubmit={handleLogin} className="space-y-5">
          <input 
            type="email" 
            placeholder="ইমেইল এড্রেস" 
            className="w-full p-4 border rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
            value={email}
            onChange={e => setEmail(e.target.value)}
            required
          />
          <input 
            type="password" 
            placeholder="পাসওয়ার্ড" 
            className="w-full p-4 border rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
            value={pass}
            onChange={e => setPass(e.target.value)}
            required
          />
          <button 
            type="submit" 
            disabled={submitting}
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl transition-all shadow-lg active:scale-95 disabled:bg-gray-300"
          >
            {submitting ? "Checking..." : "Sign In"}
          </button>
        </form>
        <p className="mt-8 text-center text-gray-500">
          নতুন ইউজার? <Link to="/signup" className="text-indigo-600 font-bold hover:underline">Signup করুন</Link>
        </p>
      </div>
    </div>
  );
};

const SignupPage = ({ onSignup, currentUser }: any) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const navigate = useNavigate();

  if (currentUser) return <Navigate to="/dashboard" />;

  const handleSignup = async (e: any) => {
    e.preventDefault();
    setSubmitting(true);
    const ok = await onSignup(name, email, pass);
    if (ok) navigate('/dashboard');
    setSubmitting(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-indigo-700 p-4">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl p-8">
        <h2 className="text-3xl font-black text-gray-800 mb-8 text-center tracking-tight">Join Us</h2>
        <form onSubmit={handleSignup} className="space-y-4">
          <input placeholder="পুরো নাম" className="w-full p-4 border rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none" value={name} onChange={e => setName(e.target.value)} required />
          <input type="email" placeholder="ইমেইল এড্রেস" className="w-full p-4 border rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none" value={email} onChange={e => setEmail(e.target.value)} required />
          <input type="password" placeholder="পাসওয়ার্ড" className="w-full p-4 border rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none" value={pass} onChange={e => setPass(e.target.value)} required />
          <button type="submit" disabled={submitting} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl shadow-lg transition-all disabled:bg-gray-300">
            {submitting ? "Creating..." : "Sign Up"}
          </button>
        </form>
        <p className="mt-8 text-center text-gray-500">ইতিমধ্যে অ্যাকাউন্ট আছে? <Link to="/login" className="text-indigo-600 font-bold">Login করুন</Link></p>
      </div>
    </div>
  );
};

const UserDashboard = ({ state, onLogout, onAddTx, onUseGmail }: any) => {
  const [selectedPlan, setSelectedPlan] = useState<any>(null);
  const [showSim, setShowSim] = useState(false);
  const user = state.currentUser!;

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow-sm px-6 py-4 flex justify-between items-center sticky top-0 z-10">
        <h1 className="text-xl font-bold text-indigo-700">GmailSim Pro</h1>
        <div className="flex items-center space-x-4">
          <div className="text-right hidden sm:block">
            <p className="text-sm font-bold text-gray-800 leading-tight">{user.fullName}</p>
            <p className="text-xs text-gray-500">{user.activePlan} Plan</p>
          </div>
          <button onClick={onLogout} className="bg-red-50 text-red-600 px-4 py-2 rounded-lg font-bold text-sm hover:bg-red-100 transition-colors">Logout</button>
        </div>
      </nav>

      <main className="max-w-6xl mx-auto p-4 md:p-8 space-y-8">
        <div className="bg-indigo-600 rounded-3xl p-8 text-white flex flex-col md:flex-row md:items-center justify-between shadow-xl">
          <div className="space-y-1">
            <h2 className="text-3xl font-black">Welcome back!</h2>
            <p className="text-indigo-100 font-medium">Your account creation limit: <span className="bg-white/20 px-2 py-0.5 rounded-lg">{user.remainingLimit} Slots</span></p>
          </div>
          <button 
            onClick={() => user.remainingLimit <= 0 ? alert('Please buy a plan!') : setShowSim(true)}
            className="mt-6 md:mt-0 bg-white text-indigo-600 px-8 py-3 rounded-2xl font-black shadow-lg hover:scale-105 active:scale-95 transition-all"
          >
            Create Gmail Account
          </button>
        </div>

        <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {PLANS.map(plan => (
            <div key={plan.id} className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm hover:shadow-xl transition-all flex flex-col items-center group">
              <h4 className="text-gray-400 font-bold uppercase tracking-widest text-xs mb-2">{plan.name}</h4>
              <div className="text-5xl font-black text-gray-800 mb-4 group-hover:text-indigo-600 transition-colors">${plan.price}</div>
              <p className="text-gray-500 font-medium mb-8">{plan.limit} High Quality Accounts</p>
              <button onClick={() => setSelectedPlan(plan)} className="w-full py-4 bg-gray-900 text-white rounded-2xl font-black hover:bg-indigo-600 transition-all shadow-md">Buy Now</button>
            </div>
          ))}
        </section>

        <section className="bg-white rounded-3xl border border-gray-100 p-6 md:p-8 shadow-sm">
          <h3 className="text-xl font-black text-gray-800 mb-6">Transaction History</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="text-xs text-gray-400 uppercase font-bold border-b"><th className="pb-4">Plan</th><th className="pb-4">Amount</th><th className="pb-4">Status</th><th className="pb-4">Date</th></tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {state.transactions.map((tx: any) => (
                  <tr key={tx.id} className="text-sm">
                    <td className="py-4 font-bold text-gray-800">{tx.planName}</td>
                    <td className="py-4 font-black">${tx.amount}</td>
                    <td className="py-4">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                        tx.status === 'APPROVED' ? 'bg-green-100 text-green-700' : 
                        tx.status === 'REJECTED' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'
                      }`}>{tx.status}</span>
                    </td>
                    <td className="py-4 text-gray-400">{new Date(tx.createdAt).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </main>

      {selectedPlan && <PaymentModal plan={selectedPlan} onClose={() => setSelectedPlan(null)} onAddTx={onAddTx} />}
      {showSim && <GmailSim onComplete={onUseGmail} onClose={() => setShowSim(false)} />}
    </div>
  );
};

const PaymentModal = ({ plan, onClose, onAddTx }: any) => {
  const [method, setMethod] = useState(PAYMENT_METHODS[0]);
  const [txId, setTxId] = useState('');
  const [amount, setAmount] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: any) => {
    e.preventDefault();
    setSubmitting(true);
    await onAddTx({
      planId: plan.id,
      planName: plan.name,
      amount: parseFloat(amount) || plan.price,
      method: method.name,
      transactionId: txId
    });
    setSubmitting(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-3xl p-8 shadow-2xl">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-2xl font-black text-gray-800">Payment Details</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-800 text-xl">✕</button>
        </div>
        <div className="bg-indigo-50 p-6 rounded-2xl mb-6 space-y-4">
          <div>
            <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-1">Select Method</p>
            <select className="w-full bg-transparent font-bold text-gray-800 outline-none" onChange={(e) => setMethod(PAYMENT_METHODS.find(m => m.name === e.target.value)!)}>
              {PAYMENT_METHODS.map(m => <option key={m.id} value={m.name}>{m.name}</option>)}
            </select>
          </div>
          <div className="pt-4 border-t border-indigo-100">
            <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-1">Send Payment to:</p>
            <p className="font-mono text-xs font-bold text-gray-700 break-all">{method.address}</p>
            {method.note && <p className="text-[10px] text-indigo-500 font-bold mt-2 italic">*{method.note}</p>}
          </div>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input required placeholder="টাকার পরিমাণ" className="w-full p-4 border rounded-xl font-bold" value={amount} onChange={e => setAmount(e.target.value)} />
          <input required placeholder="ট্রানজিশন আইডি (TX ID)" className="w-full p-4 border rounded-xl font-bold" value={txId} onChange={e => setTxId(e.target.value)} />
          <button type="submit" disabled={submitting} className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-black shadow-lg hover:bg-indigo-700 active:scale-95 transition-all disabled:bg-gray-300">
            {submitting ? "Processing..." : "Submit Transaction"}
          </button>
        </form>
      </div>
    </div>
  );
};

const AdminDashboard = ({ state, onLogout, onUpdateTx }: any) => {
  const pending = state.transactions.filter((t: any) => t.status === 'PENDING');
  const approved = state.transactions.filter((t: any) => t.status === 'APPROVED');

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col font-sans">
      <nav className="bg-white border-b px-6 py-4 flex justify-between items-center sticky top-0 z-10">
        <div className="flex items-center space-x-2">
          <span className="bg-red-600 text-white p-1 rounded-lg text-xs font-black">ADMIN</span>
          <h1 className="text-lg font-black tracking-tight">Control Panel</h1>
        </div>
        <button onClick={onLogout} className="text-gray-400 hover:text-red-600 font-bold text-sm transition-colors">Logout</button>
      </nav>
      <main className="max-w-6xl mx-auto w-full p-6 md:p-8 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100"><p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Total Users</p><p className="text-4xl font-black mt-2">{state.users.length}</p></div>
          <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100"><p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Pending Tx</p><p className="text-4xl font-black mt-2 text-orange-500">{pending.length}</p></div>
          <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100"><p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Successful</p><p className="text-4xl font-black mt-2 text-green-600">{approved.length}</p></div>
        </div>

        <section className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="px-8 py-6 border-b flex items-center justify-between">
            <h3 className="font-black text-xl">Pending Approvals</h3>
            <span className="bg-orange-100 text-orange-600 px-3 py-1 rounded-full text-[10px] font-black">{pending.length} NEW</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-gray-50/50 text-gray-400 text-[10px] uppercase font-black">
                <tr><th className="px-8 py-4">User Email</th><th className="px-8 py-4">Payment Info</th><th className="px-8 py-4">TX ID</th><th className="px-8 py-4 text-center">Actions</th></tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {pending.map((tx: any) => (
                  <tr key={tx.id} className="text-sm hover:bg-gray-50 transition-colors">
                    <td className="px-8 py-6 font-bold text-gray-800">{tx.userEmail}</td>
                    <td className="px-8 py-6">
                      <p className="font-black text-indigo-600">{tx.planName}</p>
                      <p className="text-xs font-bold text-gray-400">${tx.amount} via {tx.method}</p>
                    </td>
                    <td className="px-8 py-6"><span className="font-mono text-[10px] bg-gray-100 px-2 py-1 rounded-md text-gray-500">{tx.transactionId}</span></td>
                    <td className="px-8 py-6">
                      <div className="flex justify-center space-x-2">
                        <button onClick={() => onUpdateTx(tx.id, 'APPROVED')} className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-xl text-xs font-black shadow-md transition-all">Approve</button>
                        <button onClick={() => onUpdateTx(tx.id, 'REJECTED')} className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-xl text-xs font-black shadow-md transition-all">Reject</button>
                      </div>
                    </td>
                  </tr>
                ))}
                {pending.length === 0 && <tr><td colSpan={4} className="px-8 py-12 text-center text-gray-400 font-medium">No pending payments to review.</td></tr>}
              </tbody>
            </table>
          </div>
        </section>

        <section className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="px-8 py-6 border-b"><h3 className="font-black text-xl">System Users</h3></div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-gray-50/50 text-gray-400 text-[10px] font-black uppercase">
                <tr><th className="px-8 py-4">Name</th><th className="px-8 py-4">Email</th><th className="px-8 py-4">Plan</th><th className="px-8 py-4">Credits Left</th></tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {state.users.map((u: any) => (
                  <tr key={u.id} className="text-sm">
                    <td className="px-8 py-4 font-bold">{u.fullName} {u.role === 'ADMIN' && <span className="bg-red-600 text-white px-1.5 py-0.5 rounded text-[8px] ml-1">ADMIN</span>}</td>
                    <td className="px-8 py-4 text-gray-500">{u.email}</td>
                    <td className="px-8 py-4 font-black text-indigo-600">{u.activePlan}</td>
                    <td className="px-8 py-4 font-black text-green-600">{u.remainingLimit}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
};

export default App;
