
import React, { useState } from 'react';

interface GmailSimProps {
  onClose: () => void;
  onComplete: () => void;
}

const GmailSim: React.FC<GmailSimProps> = ({ onClose, onComplete }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    username: '',
    password: '',
    confirmPassword: ''
  });

  const nextStep = (e: React.FormEvent) => {
    e.preventDefault();
    if (step < 3) setStep(step + 1);
    else {
      onComplete();
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-white z-[100] flex flex-col items-center justify-center google-font">
      <div className="w-full max-w-[450px] p-6 md:p-10 border rounded-lg shadow-sm">
        <div className="flex flex-col items-center mb-8">
          <svg className="w-20 mb-4" viewBox="0 0 75 24" fill="none">
            <path d="M12.64 12.03V14.53H19.18C18.99 16.4 17.1 19.03 12.64 19.03C8.79 19.03 5.66 15.84 5.66 11.89C5.66 7.94 8.79 4.75 12.64 4.75C14.83 4.75 16.3 5.66 17.14 6.47L19.11 4.54C17.84 3.36 15.52 2.25 12.64 2.25C7.32 2.25 3 6.57 3 11.89C3 17.21 7.32 21.53 12.64 21.53C18.21 21.53 21.9 17.61 21.9 12.18C21.9 11.45 21.82 10.74 21.68 10.03H12.64V12.03Z" fill="#4285F4"/>
            <path d="M30.73 17.43C28.23 17.43 26.21 15.42 26.21 12.89C26.21 10.36 28.23 8.35 30.73 8.35C33.23 8.35 35.25 10.36 35.25 12.89C35.25 15.42 33.23 17.43 30.73 17.43ZM30.73 6.25C26.83 6.25 23.61 9.25 23.61 12.89C23.61 16.53 26.83 19.53 30.73 19.53C34.63 19.53 37.85 16.53 37.85 12.89C37.85 9.25 34.63 6.25 30.73 6.25Z" fill="#EA4335"/>
            <path d="M46.12 17.43C43.62 17.43 41.6 15.42 41.6 12.89C41.6 10.36 43.62 8.35 46.12 8.35C48.62 8.35 50.64 10.36 50.64 12.89C50.64 15.42 48.62 17.43 46.12 17.43ZM46.12 6.25C42.22 6.25 39 9.25 39 12.89C39 16.53 42.22 19.53 46.12 19.53C50.02 19.53 53.24 16.53 53.24 12.89C53.24 9.25 50.02 6.25 46.12 6.25Z" fill="#FBBC05"/>
            <path d="M60.67 19.53C58.8 19.53 57.14 18.52 56.41 17.21V18.89H53.9V6.6H56.5V11.53C57.23 10.22 58.89 9.21 60.76 9.21C63.95 9.21 66.86 12.03 66.86 15.87C66.86 19.71 63.95 22.53 60.67 22.53L60.67 19.53ZM60.28 17.43C62.11 17.43 64.21 15.86 64.21 12.89C64.21 9.92 62.11 8.35 60.28 8.35C58.45 8.35 56.5 9.92 56.5 12.89C56.5 15.86 58.45 17.43 60.28 17.43Z" fill="#4285F4"/>
            <path d="M70.16 2.25V21.53H72.76V2.25H70.16Z" fill="#34A853"/>
          </svg>
          <h1 className="text-2xl font-normal text-[#202124] mb-2">Create your Google Account</h1>
          <p className="text-base text-[#202124]">Continue to Gmail</p>
        </div>

        <form onSubmit={nextStep}>
          {step === 1 && (
            <div className="space-y-4">
              <div className="flex space-x-2">
                <input 
                  required
                  placeholder="First name"
                  className="w-1/2 p-3 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none"
                  value={formData.firstName}
                  onChange={e => setFormData({...formData, firstName: e.target.value})}
                />
                <input 
                  required
                  placeholder="Last name"
                  className="w-1/2 p-3 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none"
                  value={formData.lastName}
                  onChange={e => setFormData({...formData, lastName: e.target.value})}
                />
              </div>
              <div className="mt-4">
                <input 
                  required
                  placeholder="Username"
                  className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none"
                  value={formData.username}
                  onChange={e => setFormData({...formData, username: e.target.value})}
                />
                <p className="text-xs text-gray-500 mt-1">You can use letters, numbers & periods</p>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div className="flex space-x-2">
                <input 
                  required
                  type="password"
                  placeholder="Password"
                  className="w-1/2 p-3 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none"
                  value={formData.password}
                  onChange={e => setFormData({...formData, password: e.target.value})}
                />
                <input 
                  required
                  type="password"
                  placeholder="Confirm"
                  className="w-1/2 p-3 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 outline-none"
                  value={formData.confirmPassword}
                  onChange={e => setFormData({...formData, confirmPassword: e.target.value})}
                />
              </div>
              <p className="text-xs text-gray-500">Use 8 or more characters with a mix of letters, numbers & symbols</p>
            </div>
          )}

          {step === 3 && (
            <div className="text-center py-4">
              <p className="text-green-600 font-medium text-lg">Verification Successful!</p>
              <p className="text-gray-600 mt-2">Finalizing your account setup...</p>
            </div>
          )}

          <div className="flex items-center justify-between mt-10">
            <button 
              type="button"
              onClick={onClose}
              className="text-blue-600 font-medium hover:bg-blue-50 px-4 py-2 rounded transition-colors"
            >
              Cancel
            </button>
            <button 
              type="submit"
              className="bg-[#1a73e8] hover:bg-[#185abc] text-white px-6 py-2 rounded font-medium transition-colors"
            >
              {step === 3 ? 'Finish' : 'Next'}
            </button>
          </div>
        </form>
      </div>
      <p className="text-xs text-red-500 font-bold mt-10 uppercase tracking-widest">Simulation Only - No real account created</p>
    </div>
  );
};

export default GmailSim;
