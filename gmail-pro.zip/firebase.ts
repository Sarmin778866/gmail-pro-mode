
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyAM88wNDcRH-vVFFckioA9YD-Rjq75bYOw",
  authDomain: "pro-94ed8.firebaseapp.com",
  projectId: "pro-94ed8",
  storageBucket: "pro-94ed8.firebasestorage.app",
  messagingSenderId: "330788229774",
  appId: "1:330788229774:web:fd9cd7513a85e8ae6d2fdf",
  measurementId: "G-Q4TGEJKJV3"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
