
export type UserRole = 'USER' | 'ADMIN';

export interface User {
  id: string;
  fullName: string;
  email: string;
  password?: string;
  role: UserRole;
  activePlan: string;
  gmailLimit: number;
  remainingLimit: number;
}

export interface Plan {
  id: string;
  name: string;
  price: number;
  limit: number;
}

export type TransactionStatus = 'PENDING' | 'APPROVED' | 'REJECTED';

export interface Transaction {
  id: string;
  userId: string;
  userEmail: string;
  planId: string;
  planName: string;
  amount: number;
  method: string;
  transactionId: string;
  status: TransactionStatus;
  createdAt: string;
}

export interface AppState {
  users: User[];
  transactions: Transaction[];
  currentUser: User | null;
}
