
import { Plan } from './types';

export const PLANS: Plan[] = [
  { id: 'p1', name: 'Plan 1', price: 5, limit: 100 },
  { id: 'p2', name: 'Plan 2', price: 10, limit: 200 },
  { id: 'p3', name: 'Plan 3', price: 25, limit: 500 },
];

export const PAYMENT_METHODS = [
  { id: 'usdt-bep20', name: 'USDT (BEP20)', address: '0x538fa802ecd6fb6986b49213f94b0a2584540c68' },
  { id: 'usdt-trc20', name: 'USDT (TRC20)', address: 'TTsTKA2VVah7nHbSDzW3Q7ZWcmkPJ1eJXW' },
  { id: 'ltc', name: 'LiteCoin (LTC)', address: 'LiACQmuT8Sv5JhmwRENSSgU3kohrgcfFVQ' },
  { id: 'nagad', name: 'Nagad (Personal)', address: '01860333750', note: 'Send equivalent amount in BDT based on current rate.' },
];

export const ADMIN_EMAIL = 'sarminmylife@gmail.com';
